package main

import (
	"log"
	"user-service/internal/config"
	"user-service/internal/delivery/http"
	"user-service/internal/repository/sqlite"
	"user-service/internal/usecase"

	"github.com/gin-gonic/gin"
)

func main() {
	// Инициализация конфигурации (в том числе SQLite и JWT)
	db := config.InitDB("user.db")
	jwtSecret := config.GetJWTSecret()

	// Репозиторий и бизнес-логика
	userRepo := sqlite.NewUserRepository(db)
	userUsecase := usecase.NewUserUsecase(userRepo, jwtSecret)

	// HTTP хендлер
	handler := http.NewHandler(userUsecase)

	// Запуск Gin
	r := gin.Default()

	// Роуты
	handler.RegisterRoutes(r)

	// Старт сервера
	if err := r.Run(":8080"); err != nil {
		log.Fatal(err)
	}
}
