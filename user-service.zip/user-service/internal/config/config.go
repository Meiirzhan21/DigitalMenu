package config

import (
	"log"

	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var jwtSecret = []byte("supersecretkey") // можешь заменить на .env позже

// InitDB открывает подключение к SQLite и возвращает *gorm.DB
func InitDB(path string) *gorm.DB {
	db, err := gorm.Open(sqlite.Open(path), &gorm.Config{})
	if err != nil {
		log.Fatalf("не удалось подключиться к базе данных: %v", err)
	}

	return db
}

// GetJWTSecret возвращает секретный ключ для JWT
func GetJWTSecret() []byte {
	return jwtSecret
}
