package domain

import "context"

// User — модель пользователя
type User struct {
	ID       uint   `gorm:"primaryKey" json:"id"`
	Name     string `json:"name"`
	Email    string `gorm:"unique" json:"email"`
	Password string `json:"-"`
}

// UserRepository — интерфейс для взаимодействия с БД
type UserRepository interface {
	Create(ctx context.Context, user *User) error
	GetByEmail(ctx context.Context, email string) (*User, error)
	GetByID(ctx context.Context, id uint) (*User, error)
}

// UserUsecase — интерфейс бизнес-логики
type UserUsecase interface {
	Register(ctx context.Context, name, email, password string) error
	Login(ctx context.Context, email, password string) (string, error)
	GetProfile(ctx context.Context, id uint) (*User, error)
}
