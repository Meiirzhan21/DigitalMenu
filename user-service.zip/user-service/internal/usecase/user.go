package usecase

import (
	"context"
	"errors"
	"time"
	"user-service/internal/domain"

	"github.com/golang-jwt/jwt/v4"
	"golang.org/x/crypto/bcrypt"
)

type userUsecase struct {
	repo      domain.UserRepository
	jwtSecret []byte
}

func NewUserUsecase(r domain.UserRepository, secret []byte) domain.UserUsecase {
	return &userUsecase{
		repo:      r,
		jwtSecret: secret,
	}
}

func (u *userUsecase) Register(ctx context.Context, name, email, password string) error {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	user := &domain.User{
		Name:     name,
		Email:    email,
		Password: string(hashedPassword),
	}

	return u.repo.Create(ctx, user)
}

func (u *userUsecase) Login(ctx context.Context, email, password string) (string, error) {
	user, err := u.repo.GetByEmail(ctx, email)
	if err != nil {
		return "", errors.New("invalid email or password")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		return "", errors.New("invalid email or password")
	}

	// Создание JWT
	claims := jwt.MapClaims{
		"user_id": user.ID,
		"exp":     time.Now().Add(time.Hour * 72).Unix(),
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signedToken, err := token.SignedString(u.jwtSecret)
	if err != nil {
		return "", err
	}

	return signedToken, nil
}

func (u *userUsecase) GetProfile(ctx context.Context, id uint) (*domain.User, error) {
	return u.repo.GetByID(ctx, id)
}
